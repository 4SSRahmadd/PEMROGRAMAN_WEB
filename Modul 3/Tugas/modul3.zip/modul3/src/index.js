import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import logo from './asset/logo-ilab.png';
import logopesbuk from './asset/logo-facebook.png';
import logoig from './asset/logo-instagram.png';
import logox from './asset/logo-twitter.png';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
      <div class="container-fluid">
        <a class="navbar-brand" href="#"><img class="ms-5"src="asset/logo-ilab.png" alt="" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://www.instagram.com/labit.umm/">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " aria-current="page" href="http://informatika.umm.ac.id/">Contact</a>
            </li>
          </ul>
          <button type="button" class="btn btn-outline-secondary">Sign Up</button>
          <button class="btn btn-primary ms-3" type="submit">LOG IN</button>
        </div>
      </div>
    </nav>

    <section class="hero">
      <div class="row">
          <div class="col-6">
              <div class="caption">
                  <h1>Selamat datang</h1>
              <p>di website Praktikum Pemrograman website</p>
              </div>
              
          </div>
      </div>
    </section>

    <div class="footer">
      <div class="container">
  <div class="row">
      <div class="col-3">
          <img src={logo} alt="" />
          <p class="mt-5">Copyright © 2022. Infinite Learning</p>
      </div>
      <div class="foot-caption col-3">
          <p class="top-foot">Service</p>
          <p>EmailMarketing</p>
          <p>Campaign</p>
          <p>Branding</p>
          <p>Office</p>
      </div>
      <div class="foot-caption col-3">
          <p class="top-foot">About</p>
          <p>Our Story</p>
          <p>Benefits</p>
          <p>Team</p>
          <p>Careers</p>
      </div>
      <div class="foot-caption col-3">
          <p class="top-foot">Follow us</p>
          <p><img class="logo-pesbuk"src={logopesbuk} alt="" />Facebook</p>
          <p><img class="logo" src={logoig} alt="" />Instagram</p>
          <p><img class="logo" src={logox} alt="" />Twitter</p>
      </div>
    </div>
  </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
